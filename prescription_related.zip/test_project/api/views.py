from django.shortcuts import render
from django.http import JsonResponse,HttpResponse
from test_app.models import prescription
# Create your views here.

def get_list_format(temp_list):
  full_list=[]
  for i in temp_list:
    full_list.append(
      {
        'name':i.name,
        'doctor':i.doctor,
        'date':i.date,
        'comment':i.comment,
      }
    )
  return full_list


def req_name(request,name=None):
    with open('log.txt','w') as f:
        f.write(f'{request.__dict__}')
    temp_list=prescription.objects.filter(name=name)
    full_list=get_list_format(temp_list)
    return JsonResponse(full_list,safe=False)
