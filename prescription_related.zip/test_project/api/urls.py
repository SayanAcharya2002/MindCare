from django.urls import path,include
from .views import req_name
urlpatterns=[
    path('<str:name>/',req_name,name='req_name'),

]