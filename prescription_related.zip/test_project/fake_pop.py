import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE",'test_project.settings')

import django
django.setup()

import random
from faker import Faker
from test_app.models import prescription

fake_gen=Faker()

whole_alphabet=[chr(i) for i in range(ord('a'),ord('z')+1)]

def populate(n):
  for i in range(n):
    name=fake_gen.name()
    doctor='Dr. '+fake_gen.name()
    date=fake_gen.date()
    comment=''.join([random.choice(whole_alphabet) for _ in range(20)])
    prescription.objects.get_or_create(name=name,doctor=doctor,date=date,comment=comment)


# populate(5)

#show the records

# for i in prescription.objects.all():
#   i.save()
print(prescription.objects.all())