from django.db import models

# Create your models here.

class prescription(models.Model):
  name=models.CharField(max_length=100)
  # medicines=models.CharField(max_length=100)
  doctor=models.CharField(max_length=100)
  date=models.DateField()
  comment=models.CharField(max_length=1000)

  def __str__(self):
    return f"{self.name} {self.doctor} {self.date} {self.comment}"

