from django.http import HttpRequest, HttpResponse
from django.shortcuts import render
from .models import prescription
import datetime as dt

# Create your views here.

def date_time_hash(d:prescription):
  d=str(d.date)
  ret=int(d[:4])*1e4+int(d[5:7])*1e2+int(d[:-3:-1])
  return ret
  # print(d)
  # listy=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
  # mappa=dict(zip(listy,range(1,13)))
  # month=mappa[d[:3]]
  # day=d[5:7]
  # year=d[9::]
  # return year*1e4+month*1e2+day


def index(request:HttpRequest):
  if request.method=='GET':
    form_val=request.GET.dict()
    # print(form_val)
    if form_val.get('name')!=None:
      prescription.objects.order_by('date')
      pres_rows=prescription.objects.filter(name=form_val['name'])
      pres_rows=sorted(pres_rows,key=date_time_hash,reverse=True)
      

      return render(request,'test_app/index.html',{
        'pres_rows':pres_rows,
      })
    else:
      return render(request,'test_app/index_form.html',{

      })
  else:
    return HttpResponse('<h1>Malformatted query</h1>')

def index_give_prescription(request:HttpRequest):
  if request.method=='GET':
    form_val=request.GET.dict()
    if len(form_val)!=0:
      form_val['doctor']='Dr. '+form_val['doctor']
      prescription.objects.create(**form_val)
      print(str(prescription.objects.get(**form_val)))
      return render(request,'test_app/thanks.html',{})
    else:
      return render(request,'test_app/index_give_pres.html',{})