from django.urls import path
from .views import *
urlpatterns=[
  path('form/',index_give_prescription,name='index_give_prescription/'),
  path('',index,name='index'),
]