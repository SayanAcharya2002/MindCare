from django.http import HttpResponse
from django.shortcuts import render
from .models import forum_post
import datetime as dtt

def get_file_content(file_name):
  with open(file_name) as f:
    listy=f.readlines()
  return listy

import os
# Create your views here.

def date_hash(x):
  return str(x.date)

def forum_index(request):
  # total_files=get_file_content(r'D:\Programming\WebDev+BackEnd\new_test_project\new_test_app\forum_file.txt')

  # clean_please=forum_post.objects.filter(text_content='')
  # clean_please=forum_post.objects.all()
  # clean_please.delete()
  if(request.method=='POST'):
    if(len(request.POST.dict())!=0):
      all_form=request.POST.dict()
      forum_post.objects.create(text_content=all_form['text_content'],name=all_form['name'],date=dtt.datetime.utcnow())
    
    all_content=forum_post.objects.all()
    all_content=sorted(all_content,key=date_hash,reverse=True)
    print(all_content)
    print(f"this is the length: {len(all_content)}")
    # total_files=get_file_content(r'./new_test_app/forum_file.txt')
    return render(request,['new_test_app/index.html','new_test_app/index.css'],{
      'all_content':all_content,

    })
  else:
    all_content=forum_post.objects.all()
    return render(request,'new_test_app/index.html',{'all_content':all_content})
