from django.apps import AppConfig


class NewTestAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'new_test_app'
