from django.db import models

# Create your models here.

class forum_post(models.Model):
  text_content=models.CharField(max_length=1000)
  name=models.CharField(max_length=100)
  date=models.DateTimeField()

  def __str__(self):
    return f"{self.text_content} {self.name} {self.date}"