from django.urls import path
from .views import *

urlpatterns = [
    # path('<int:val>/',ints),
    # path('<slug:slug>/',slug),
    path('forum/',forum_index),
    
]
