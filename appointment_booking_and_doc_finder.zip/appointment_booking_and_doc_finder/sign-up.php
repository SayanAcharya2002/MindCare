<?php 
session_start();
$_SESSION['auth'] = FALSE;
$_SESSION['username'] = "";
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.png">
    <link rel="shortcut icon" href="./favicon.png" type="image/x-icon">
    <title>Signup to MindCare</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.1/examples/sign-in/">

    <!-- Bootstrap core CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="https://getbootstrap.com/docs/4.1/examples/sign-in/signin.css" rel="stylesheet">
</head>
<body class="text-center">
<form class="form-signin" id="sign-up" method="post">
    <div class="p-3 border border-secondary border-2">
        <img class="mb-4" src="favicon.png" alt="" width="100">
        <h1 class="h3 mb-3 font-weight-normal">Sign up Here</h1>
        <label for="inputUsername" class="sr-only">Username</label>
        <input type="username" id="inputUsername"  class="form-control" name="username" placeholder="Username" required autofocus>
        <label for="inputEmail" class="sr-only">Email address</label>
        <input type="email" id="inputEmail"  class="form-control" name="email" placeholder="Email address" required autofocus>
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" id="inputPassword" class="form-control" name="password" placeholder="Password" required>
        <div class="checkbox mb-3">
            <label>
                <input type="checkbox" value="remember-me"> Remember me
            </label>
        </div>
        <!-- <a class="btn btn-lg btn-primary btn-block" href="" id="signUp">Sign up</a> -->
        <button class="btn btn-lg btn-success btn-block" type="submit" name="signup" type="button" id="signup">Signup</button>
        <br>
        <!-- <button class="btn btn-success btn-block my-3"><a href="https://forms.gle/3zqeGUd7uhJSyt2DA" target="_blank"
            style="color: white; text-decoration-line: none;">Help us to Know You better</a></button> -->
        <button class="btn btn-primary btn-block my-3"><a href="sign-in.php"
                style="color: white; text-decoration-line: none;">Sign In</a></button>
        <button class="btn btn-secondary btn-block my-3"><a href="https://mind-care.netlify.app/"
                style="color: white; text-decoration-line: none;">Back to Home</a></button>                
        <br>        

        <?php
        //session_start();
        function f($str1,$str2){
            return sha1($str1.$str2);
        }
        if(isset($_POST['signup'])){
            $con = mysqli_connect("localhost","root","","appointment_db");
            $uname = $_POST['username'];
            $email = $_POST['email'];
            $pword = $_POST['password'];
            $id = f($uname,$email);
            //$pword = f($pword,$uname);
            $flag=0;
            $query = "SELECT * FROM users WHERE Email='$email'";
            $query_run = mysqli_query($con,$query);
            if(mysqli_num_rows($query_run)>0){
                echo("Email already taken!! Please use another one.");
                $flag = 1;
            }
            $query2 = "SELECT * FROM users WHERE Username='$uname'";
            $query_run_2 = mysqli_query($con,$query2);
            if(mysqli_num_rows($query_run_2)>0){
                echo("Username already taken!! Please use another one.");
                $flag = 1;
            }
            if($flag==0){
                $query_3 = "INSERT INTO users(`User_id`, `Username`, `Email`, `Password`) VALUES('$id','$uname','$email','$pword')";
                $query_run_3 = mysqli_query($con,$query_3);
                $_SESSION['auth'] = TRUE;
                $_SESSION['username'] = $uname;
                header('location: ./appointment.php');
            }
            
        }
        ?>
        <p class="mt-5 mb-3 text-muted">&copy; MindCare 2022</p>
    </div>    
</form>
<script src="./index.js" type="module"></script>

</body>

</html>