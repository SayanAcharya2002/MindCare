<?php 
session_start();
$_SESSION['auth'] = FALSE;
$_SESSION['username'] = "";
//session_reset();
session_destroy();
session_abort();
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.png">

    <title>Sign Out from MindCare</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.1/examples/sign-in/">

    <!-- Bootstrap core CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="https://getbootstrap.com/docs/4.1/examples/sign-in/signin.css" rel="stylesheet">
</head>
<body class="text-center">
<form class="form-signin" id="sign-up" method="post">
    <div class="p-3 border border-secondary border-2">
        <img class="mb-3" src="favicon.png" alt="" width="100">
        <h1 class="h3 mb-3 font-weight-normal">Thanks for choosing MindCare</h1>
        <!-- <label for="inputEmail" class="sr-only">Username</label>
        <input type="username" id="inputUsername" name="username" class="form-control" placeholder="Username" required autofocus>
        <label for="inputEmail" class="sr-only">Email address</label>
        <input type="email" id="inputEmail" name="email" class="form-control" placeholder="Email address" required autofocus>
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" id="inputPassword" name="password" class="form-control" placeholder="Password" required>
        <div class="checkbox mb-3">
            <label>
                <input type="checkbox" value="remember-me"> Remember me
            </label>
        </div>
        <button class="btn btn-lg btn-primary btn-block" type="submit" name="login" type="button" id="login">Login</button>
        <br> -->
        <button class="btn btn-primary btn-block my-3"><a href="https://mind-care.netlify.app/"
                style="color: white; text-decoration-line: none;">Back to Home</a></button>
        <button class="btn btn-success btn-block my-3"><a href="./sign-in.php"
                style="color: white; text-decoration-line: none;">Sign In Again</a></button>
    </div>            

        <p class="mt-5 mb-3 text-muted">&copy;MindCare 2022</p>
</form>
<?php 
//session_start();
// if(isset($_POST['login'])){
//     $con = mysqli_connect("localhost","root","","appointment_db");
//     $uname = $_POST['username'];
//     $email = $_POST['email'];
//     $pword = $_POST['password'];
//     $query = "SELECT * FROM users WHERE Email='$email' LIMIT 1";
//     $query_run = mysqli_query($con,$query);
//     $result = mysqli_fetch_array($query_run, MYSQLI_ASSOC);
//     if(count($result)>0){
//         //echo $result['Username'];
//         if(($pword==$result['Password'])&&($uname==$result['Username'])){
//             $_SESSION['auth'] = TRUE;
//             $_SESSION['username'] = $uname;
//             header('location: ./appointment.php');
//         }
//     }
    
// }

?>

<script src="./index.js" type="module"></script>

</body>

</html>