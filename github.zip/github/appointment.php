<?php 
session_start();
if(isset($_SESSION['auth'])){
if($_SESSION['auth'] != TRUE){
  header('location: ./sign-in.php');
}
}
else{
  header('location: ./sign-in.php');
}
?>

<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

<!-- Favicons -->
<link href="favicon.png" rel="icon">
  

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <!-- <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet"> 
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

   Template Main CSS File 
  <link href="assets/css/style.css" rel="stylesheet"> -->

  <title>Mind Care Appointment</title>
</head>

<body>
  <!--navigation bar-->
  <nav class="navbar navbar-expand-lg navbar-light" style="background-color:#c8fcc2;">
    <div class="container-fluid">
      <a class="navbar-brand" href="https://mind-care.netlify.app/"><img src="favicon.png" alt="logo" width="70"
          class="d-inline-block align-text-middle"> Mind Care
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link" aria-current="page" href="https://mind-care.netlify.app/">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">About Us</a>
          </li>
          <!-- <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown"
              aria-expanded="false">
              Features
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item" href="#">Live Chat</a></li>
              <li><a class="dropdown-item" href="#">Voice Channel</a></li>
              <li><a class="dropdown-item" href="#">Video Call</a></li>
              <li>
                <hr class="dropdown-divider">
              </li>
              <li><a class="dropdown-item" href="./find-your-peer.html">Find Your Peer</a></li>
            </ul>
          </li> -->
          <li class="nav-item">
            <a class="nav-link" href="https://health-chat-f5faa.web.app/">Mind Chat</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Contact Us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="./sign-out.php">Sign Out</a>
          </li>
        </ul>
        <!-- <form class="d-flex">
          <input class="form-control me-2" type="search" placeholder="Explore Here" aria-label="Search">
          <button class="btn btn-outline-success" type="submit">Search</button>
        </form> -->
      </div>
    </div>
  </nav>
  

  <script>
  window.watsonAssistantChatOptions = {
      integrationID: "7b34e6a0-ff51-45dc-b65f-d3384ff7b4d7", // The ID of this integration.
      region: "au-syd", // The region your integration is hosted in.
      serviceInstanceID: "c7f89b0d-2325-4bbd-aec9-cf86f41c23c2", // The ID of your service instance.
      onLoad: function(instance) { instance.render(); }
    };
  setTimeout(function(){
    const t=document.createElement('script');
    t.src="https://web-chat.global.assistant.watson.appdomain.cloud/versions/" + (window.watsonAssistantChatOptions.clientVersion || 'latest') + "/WatsonAssistantChatEntry.js"
    document.head.appendChild(t);
  });
</script>

  <!--alert-->
  <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
    <symbol id="check-circle-fill" fill="currentColor" viewBox="0 0 16 16">
      <path
        d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z" />
    </symbol>
    <symbol id="info-fill" fill="currentColor" viewBox="0 0 16 16">
      <path
        d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z" />
    </symbol>
  </svg>
  <div class="alert alert-warning d-flex align-items-center alert-dismissible fade show" role="alert">
    <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Info:">
      <use xlink:href="#info-fill" />
    </svg>
    <div>
      <strong>New here?</strong> Go to Mind Chat App to directly consult our doctors! 
    </div>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>

  <!--carousel-->

  <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <!-- <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button> -->
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="carousel-5.1.jfif" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="carousel-5.2.jfif" class="d-block w-100" alt="...">
    </div>
    <!-- <div class="carousel-item">
      <img src="carousel-5.3.jfif" height="1400" width="500" class="d-block w-100" alt="...">
    </div> -->
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

  <!--body-->
<br>  
<?php
//session_start();
?> 
<h2><b>Appointment & Prescription Assistant</b></h2>
<form method="post" class="book" action="">
<div class="container">
  <div class="row">
      <div class="col-md-12">
          <div class="card mt-4">
              <div class="card-header bg-success bg-opacity-25">
                  <h4>Book Your Appointment</h4>
              </div>
              <div class="card-body">
                  <div class="row">
                  <div class="row">
            <div class="col-md-4 form-group">
              <input type="text" name="namename" class="form-control" required id="namename" placeholder="Your Username" value="<?php if(isset($_POST['namename'])){echo($_POST['namename']); } ?>" data-rule="minlen:4" data-msg="Please enter at least 4 chars">
              <div class="validate"></div>
            </div>
            <div class="col-md-4 form-group mt-3 mt-md-0">
              <input type="email" class="form-control" name="email" required id="email" placeholder="Your Email" value="<?php if(isset($_POST['email'])){echo($_POST['email']); } ?>" data-rule="email" data-msg="Please enter a valid email">
              <div class="validate"></div>
            </div>
            <div class="col-md-4 form-group mt-3 mt-md-0">
              <input type="tel" class="form-control" name="age" required id="age" placeholder="Your Age" value="<?php if(isset($_POST['age'])){echo($_POST['age']); } ?>" data-rule="minlen:4" data-msg="Please enter at least 4 chars">
              <div class="validate"></div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-4 form-group mt-3">
              <input type="datetime" name="date" class="form-control datepicker" id="date" required placeholder="Appointment Date(yyyy-mm-dd)" value="<?php if(isset($_POST['date'])){echo($_POST['date']); } ?>" data-rule="minlen:4" data-msg="Please enter at least 4 chars">
              <div class="validate"></div>
            </div>
            <div class="col-md-4 form-group mt-3">
              <select name="doctor" id="doctor" class="form-select">
                <option value="">Select Doctor</option>
                <option value="Dr. Ram Sarkar">Dr. Ram Sarkar</option>
                <option value="Dr. Shalini Sengupta">Dr. Shalini Sengupta</option>
                <option value="Dr. Aaron Kim">Dr. Aaron Kim</option>
                <option value="Dr. T.S. Vengaokar">Dr. T.S. Vengaokar</option>
                <option value="Dr. Shreyan Gupta">Dr. Shreyan Gupta</option>
                <option value="Dr. N.R Rao">Dr. N.R Rao</option>
                <option value="Dr. Ramkrishna Murti">Dr. Ramkrishna Murti</option>
                <option value="Dr. Vijay Kumar">Dr. Vijay Kumar</option>
                <option value="Dr. Rahul Sharma">Dr. Rahul Sharma</option>
              </select>
              <div class="validate"></div>
            </div>
            <div class="form-check">
            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" checked>
            <label class="form-check-label" for="flexRadioDefault1">
                Online Appointment
            </label>
            </div>
            <div class="form-check">
            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2">
            <label class="form-check-label" for="flexRadioDefault2">
                In-Person Appointment
            </label>
            </div>
            
            <div class="text-center"><button type="submit" class="btn btn-success" name="app">Make an Appointment</button></div>


                      


                          <!-- <form action="" class="search" method="GET">
                              <div class="input-group mb-3">
                                  <input id="clear" type="text" name="search" required value="" class="form-control" placeholder="Search by your Appointment ID, Name, Doctor's Name">
                                  <button id="btn" type="submit" class="btn btn-primary">Search</button>
                              </div>
                          </form> -->

                      </div>
                  </div>
              </div>
          </div>
      </div>
</div>
<?php
function f($str1,$str2,$str3){
    return sha1($str1.$str2.$str3);
}
 ?>
      <?php
            //session_start();
            $con = mysqli_connect("localhost","root","","appointment_db");
            if(isset($_POST['app'])){ 
            
            $doc_name = $_POST['doctor'];
            //echo($doc_name);
            $name = $_POST['namename']; 
            //echo($name);
            $date = $_POST['date'];
            $age = $_POST['age'];
            //$id = f($name,$doc_name,$date);
            $str = ":00:00";
            if($_SESSION['username']==$name){
            for ($x=10;$x<=18;$x++)
            {
                $y = (string)$x;
                $date_2 = $date." ".$y.$str;
                $id = f($name,$doc_name,$date_2);
                //$date_3 = new D$date_2);
                $query_1 = "SELECT * FROM appointment WHERE App_Date='$date_2' AND Doc_Name='$doc_name'";
                $query_run_1 = mysqli_query($con, $query_1);
                if(mysqli_num_rows($query_run_1)>0){
                    continue;
                }
                else{
                    $query_2 = "INSERT INTO appointment VALUES ('$id','$doc_name','$name',$age,'$date_2')";
                    $query_run_2 = mysqli_query($con, $query_2);
                    $query_3 = "SELECT * FROM appointment WHERE App_Id='$id'";
                    $query_run_3 = mysqli_query($con, $query_3);
                    $result = mysqli_fetch_array($query_run_3, MYSQLI_ASSOC);
                    //echo($result);
                    //echo($query_run_3);
                    //foreach($query_run_3 as $res){
                    echo("Appointment Booked Successfully for ".$result["Patient_name"]." at ".$result['App_date']." !!</br>");
                    echo("Your Appointment ID is ".$result["App_Id"]); ?>
                    <p>Please click to complete your payment : <span><button id="btn" type="submit" class="btn btn-success"><a href="https://pages.razorpay.com/pl_Imv6lQot7281jv/view" style="text-decoration:None; color:white;" target="_blank">Pay</a></button></span></p>
                    <?php break;
                }
            }
          }
          else{
            echo("  Please provide your own username!!!");
          }

            }    
            
            // $query = "INSERT INTO appointment VALUES ('1851249318229162','$doc_name','$name',$age,'$date')";
            // $query_run = mysqli_query($con, $query);}
      ?>
      </div>
          </form>


<div class="container">
  <div class="row">
      <div class="col-md-12">
          <div class="card mt-4">
              <div class="card-header bg-primary bg-opacity-25">
                  <h4>Find Your Latest Appointment</h4>
              </div>
              <div class="card-body">
                  <div class="row">
                      <div class="col-md-7">

                          <form action="" class="search" method="post">
                              <div class="input-group mb-3">
                                  <input id="clear" type="text" name="appsearch" value="<?php if(isset($_POST['appsearch'])){echo($_POST['appsearch']); } ?>" class="form-control" placeholder="Search by your Appointment ID, Name, Doctor's Name">
                                  <button id="btn"  name="search" type="submit" class="btn btn-primary">Search</button>
                              </div>
                          </form>

                      </div>
                  </div>
              </div>
          
        
    <!-- <script>
      const obj = document.querySelector('.search')
      if (obj) {
          obj.addEventListener('submit', (e) => {
              e.preventDefault()


              // const docRef = doc(db, 'books', deleteBookForm.id.value)

              // deleteDoc(docRef)
                  .then(() => {
                      // alert("Book deleted!");
                      obj.reset()
                  })
          })
      }
    </script> -->




      <div class="col-md-12">
          <div class="card mt-4">
              <div class="card-body">
                  <table class="table table-bordered">
                      <thead>
                          <tr>
                              <!-- <th>ID</th> -->
                              <th>Appointment ID</th>
                              <th>Doctor's Name</th>
                              <th>Patient's Name</th>
                              <th>Patient's Age</th>
                              <th>Appointment Details</th>
                              <!-- <th>Faculty</th>
                              <th>Department</th>
                              <th>Batch</th>
                              <th>Skills</th>
                              <th>Profile Links</th> -->
                          </tr>
                      </thead>
                      <tbody>
                          <?php 
                              //$con = mysqli_connect("localhost","id18322625_doctors","z3|fz<1OG@v[/UYC","id18322625_productathon_doctors_db");
                              $con = mysqli_connect("localhost","root","","appointment_db");
                              if(isset($_POST['appsearch']))
                              {
                                  $filtervalues = $_POST['appsearch'];
                                  $query = "SELECT * FROM appointment WHERE CONCAT(App_Id,Doc_name,Patient_name) LIKE '%$filtervalues%' ORDER BY App_date DESC LIMIT 3";
                                  $query_run = mysqli_query($con, $query);
                                  

                                  if(mysqli_num_rows($query_run) > 0)
                                  {   $flag = 0;
                                      foreach($query_run as $items)
                                      { 
                                        if($items['Patient_name']==$_SESSION['username']){
                                          $flag = 1;
                                          ?>
                                          <tr>
                                              <td><?= $items['App_Id']; ?></td>
                                              <td><?= $items['Doc_name']; ?></td>
                                              <td><?= $items['Patient_name']; ?></td>
                                              <td><?= $items['Age']; ?></td>
                                              <td><?= $items['App_date']; ?></td>
                                          </tr>
                                          <?php
                                        }
                                        else{
                                          continue;
                                        }
                                      }
                                  }
                                  else
                                  {
                                      ?>
                                          <tr>
                                              <td colspan="5">No Record Found</td>
                                          </tr>
                                      <?php
                                  }
                                  if($flag==0){
                                    ?>
                                    <tr>
                                        <td colspan="5">No Record Found</td>
                                    </tr>
                                <?php
                                  }
                              }
                          ?>
                      </tbody>
                  </table>
              </div>
          </div>
      </div>
  </div>
</div>  
                            </div>
                            </div>

<form method="post">
  <div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card mt-4">
                <div class="card-header bg-success bg-opacity-25">
                    <h4>Get Your Prescriptions</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                    <div class="col-md-5">
              <div class="input-group mb-3 form-group">
                <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" value="<?php if(isset($_POST['name'])){echo($_POST['name']);} ?>" data-rule="minlen:4" data-msg="Please enter at least 4 chars">
                <button class="btn btn-success" name="app2">Submit</button>
              
              </div>
              <!-- <div class="text-center"><button class="btn btn-success" name="app2"><a href="http://sayach2002.pythonanywhere.com/prescription/" style="text-decoration:None; color:white;" target="_blank">Submit</a></button></div> -->
              <!-- <div class="text-center"><button class="btn btn-success" name="app2">Submit</button></div> -->
          </div>   
      </div>
  </div>   
</form> 
<?php 
if(isset($_POST['app2'])){
  $pre_name = $_POST['name'];
  if(($pre_name!="") && ($_SESSION['username']==$pre_name)){
  $response = file_get_contents('http://sayach2002.pythonanywhere.com/api/'.$pre_name.'/');
  //echo $response;
  $arr = array("[","]");
  $response = str_replace($arr,"",$response);
  //echo $response;
  $arr2 = explode("},",$response);
  ?>
   <div class="col-md-12">
          <div class="card mt-4">
              <div class="card-body">
  <h5>Your Recent Prescriptions</h5><hr><?php
  if((sizeof($arr2)>0)&&($arr2[0]!="")){
  // $x = $arr2[0];
  // $x = "'".$x."}'";
  // $x1 = json_decode($x,true);
  // var_dump($x1); 
  // $json = '{"name": "Tanvir Alam", "doctor": "Dr. Ram Sarkar", "date": "2022-01-18", "comment": "He is suffering from medium levels of ADHD. I prescribe him sleeping pills."}';
  // $x1 = json_decode($x,true);
  // var_dump($x1);
  // echo "$x</br>";
  $c = 1;
  foreach($arr2 as $val){
    ?><div class="p-2 bg-light border"><?php
    echo $c.") ";
    $arr3 = array("{","}","\"");
    $val = str_replace($arr3,"",$val);
    echo "$val</br>";
    $c = $c+1;
    ?></div><?php
    // $val1 = json_decode($val);
    //print $val1->{'name'};

  }
}
else{
  echo("No records found with this username. Please book an appointment with us first!!");
}
}
else {echo("  Please use your own username!!");}
  //echo $arr2[0];
  //echo $response;
  // foreach($response as $val){
  //   $val = (string)$val;
  //   echo $val;
  //   $val1 = json_decode($val,true);
  //   print $val1->{'name'};
  // }
  //$res = json_decode($response,true);
  //print $response->{'name'};
  //echo $response;
}

?>
</div></div></div>
</div>
</div>
</div>
</div>

<!-- <div class="card" style="width: 18rem;">
  <img src="..." class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a>
  </div>
</div> -->

  <!--footer-->
  <div style="background-color: grey;">
    <footer class="text-center text-lg-start border border-white mt-xl-5 pt-4">
      <!-- Grid container -->
      <div class="container p-4">
        <!--Grid row-->
        <div class="row">
          <!--Grid column-->
          <div class="col-lg-3 col-md-6 mb-4 mb-lg-0">
            <h5 class="text-uppercase mb-4">OUR TEAM</h5>

            <ul class="list-unstyled mb-4">
              <li>
                <a href="./about-us.html" class="text-white">About us</a>
              </li>
              <li>
                <a href="#!" class="text-white">Resources</a>
              </li>
              <li>
                <a href="#!" class="text-white">Collaborations</a>
              </li>
            </ul>
          </div>
          <!--Grid column-->

          <!--Grid column-->
          <div class="col-lg-3 col-md-6 mb-4 mb-lg-0">
            <h5 class="text-uppercase mb-4">Assistance</h5>

            <ul class="list-unstyled">
              <li>
                <a href="#" class="text-white">Contact us</a>
              </li>
              <li>
                <a href="#!" class="text-white">Mind Bot</a>
              </li>
              <li>
                <a href="#!" class="text-white">Contribute</a>
              </li>
            </ul>
          </div>
          <!--Grid column-->

          <!--Grid column-->
          <div class="col-lg-3 col-md-6 mb-4 mb-lg-0">
            <h5 class="text-uppercase mb-4">Mind Care</h5>

            <ul class="list-unstyled">
              <li>
                <a href="https://mind-care.netlify.app/" class="text-white" target="_blank">Home site</a>
              </li>
              <li>
                <a href="https://health-chat-f5faa.web.app/" class="text-white" target="_blank">Mind Chat</a>
              </li>
            </ul>
          </div>
          <!--Grid column-->

          <!--Grid column-->
          <div class="col-lg-3 col-md-6 mb-4 mb-lg-0">
            <h5 class="text-uppercase mb-4">Sign up to our newsletter</h5>

            <div class="form-outline form-white mb-4">
              <input type="email" id="form5Example2" class="form-control" />
              <label class="form-label" for="form5Example2">Email address</label>
            </div>

            <!-- <p><button type="button" class="btn btn-outline-dark">Subscribe</button></p>
            <a href="#" style="text-decoration-line: none; color: black"><button type="button"
              class="btn btn-outline-light"><img src="arrow.png" width="30"></button></a> -->
          </div>
          <!--Grid column-->
        </div>
        <!--Grid row-->
      </div>
      <!-- Grid container -->

      <!-- Copyright -->
      <div class="text-center p-3 border-top border-white">
        © 2022 :
        <a class="text-white" href="https://mind-care.netlify.app/"> Mind Care</a>
      </div>
      <!-- Copyright -->
    </footer>
  </div>

  <!-- Optional JavaScript; choose one of the two! -->

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ"
    crossorigin="anonymous"></script>

  <!-- Option 2: Separate Popper and Bootstrap JS -->
  <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous"></script>
    -->


</body>

</html>