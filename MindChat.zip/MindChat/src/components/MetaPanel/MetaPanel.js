import React from "react";
import {
  Segment,
  Accordion,
  Header,
  Icon,
  Image,
  List,
  GridColumn,
  GridRow
} from "semantic-ui-react";

class MetaPanel extends React.Component {
  state = {
    channel: this.props.currentChannel,
    privateChannel: this.props.isPrivateChannel,
    activeIndex: 0
  };

  setActiveIndex = (event, titleProps) => {
    const { index } = titleProps;
    const { activeIndex } = this.state;
    const newIndex = activeIndex === index ? -1 : index;
    this.setState({ activeIndex: newIndex });
  };

  formatCount = num => (num > 1 || num === 0 ? `${num} posts` : `${num} post`);

  displayTopPosters = posts =>
    Object.entries(posts)
      .sort((a, b) => b[1] - a[1])
      .map(([key, val], i) => (
        <List.Item key={i}>
          <Image avatar src={val.avatar} />
          <List.Content>
            <List.Header as="a">{key}</List.Header>
            <List.Description>{this.formatCount(val.count)}</List.Description>
          </List.Content>
        </List.Item>
      ))
      .slice(0, 2);

  render() {
    const { activeIndex, privateChannel, channel } = this.state;
    const { userPosts } = this.props;

    if (privateChannel) return null;

    return (
      <React.Fragment>
        <div class="ui teal inverted segment">
      <Segment loading={!channel} >
      
        <Header as="h3" attached="top">
          About  {channel && channel.name}
        </Header>
        <Accordion styled attached="true">
          <Accordion.Title
            active={activeIndex === 0}
            index={0}
            onClick={this.setActiveIndex}
          >
            <Icon name="dropdown" />
            <Icon name="info" />
            Channel Details
          </Accordion.Title>
          <Accordion.Content active={activeIndex === 0}>
            {channel && channel.details}
          </Accordion.Content>

          {/* <Accordion.Title
            active={activeIndex === 1}
            index={1}
            onClick={this.setActiveIndex}
          >
            <Icon name="dropdown" />
            <Icon name="user circle" />
            Top Posters
          </Accordion.Title>
          <Accordion.Content active={activeIndex === 1}>
            <List>{userPosts && this.displayTopPosters(userPosts)}</List>
          </Accordion.Content> */}

          <Accordion.Title
            active={activeIndex === 2}
            index={2}
            onClick={this.setActiveIndex}
          >
            <Icon name="dropdown" />
            <Icon name="pencil" />
            Created By
          </Accordion.Title>
          <Accordion.Content active={activeIndex === 2}>
            <Header as="h3">
              This channel was created by MindChat Admins
            </Header>
          </Accordion.Content>
        </Accordion>
      </Segment>
      
      <Segment loading={!channel} style={{backgroundcolor:"blue"}}>
      <Header as="h3" attached="top">
       <center><i>Our Team Of Doctors</i></center> 
      </Header>
      <Accordion styled attached="true">
        <Accordion.Title>
          <GridRow>
          <GridColumn width={1}>
        <Image circular src="https://media.istockphoto.com/photos/happy-doctor-looking-at-camera-picture-id1201889044?k=20&m=1201889044&s=612x612&w=0&h=R8-0geJjgLnRgtVWWbanDbS2tkM8NMT2SISQETFSfbg="  
        style={{width: '50px', height: 'auto'}}
        />
        </GridColumn>
         <GridColumn>Dr Ram Sarkar(Child Psychiatrist), Kolkata,	West Bengal	</GridColumn>
         </GridRow>
        </Accordion.Title>
        <Accordion.Title>
          <GridRow>
          <GridColumn width={1}>
        <Image circular src="https://th.bing.com/th/id/OIP.04wRfQ8jltCR4EqSC5bntQHaKD?w=123&h=185&c=7&r=0&o=5&dpr=1.25&pid=1.7"  
        style={{width: '50px', height: 'auto'}}
        />
        </GridColumn>
         <GridColumn>Dr. Shreyan Gupta (Sleep Specialist), Araria, Bihar</GridColumn>
         </GridRow>
        </Accordion.Title>
        <Accordion.Title>
          <GridRow>
          <GridColumn width={1}>
        <Image circular src="https://th.bing.com/th/id/OIP.zGHX7ZYKbSqU8pL35xyPhwHaE8?pid=ImgDet&rs=1"  
        style={{width: '50px', height: 'auto'}}
        />
        </GridColumn>
         <GridColumn>Dr. T.S. Vengaokar (Substance Misuse), Chennai, Tamil Nadu</GridColumn>
         </GridRow>
        </Accordion.Title>
        <Accordion.Title>
          <GridRow>
          <GridColumn width={1}>
        <Image circular src="https://thispersondoesnotexist.com/image"  
        style={{width: '50px', height: 'auto'}}
        />
        </GridColumn>
         <GridColumn>Dr. Aaron Kim (Child Psychiatrist),	Maharashtra, Navi Mumbai</GridColumn>
         </GridRow>
        </Accordion.Title>
        <Accordion.Title>
          <GridRow>
          <GridColumn width={1}>
        <Image circular src="https://s3-media4.fl.yelpcdn.com/buphoto/CCJQfoyGBohx8LjXiUGn9g/o.jpg"  
        style={{width: '50px', height: '50px'}}
        />
        </GridColumn>
         <GridColumn>Dr. Shalini Sengupta	(Learning Disability), Howrah,	West Bengal</GridColumn>
         </GridRow>
        </Accordion.Title>
        {/* <Accordion.Title
          active={activeIndex === 1}
          index={1}
          onClick={this.setActiveIndex}
        >
          <Icon name="dropdown" />
          <Icon name="user circle" />
          Top Posters
        </Accordion.Title>
        <Accordion.Content active={activeIndex === 1}>
          <List>{userPosts && this.displayTopPosters(userPosts)}</List>
        </Accordion.Content> */}

        
      </Accordion>
      
    </Segment>
    </div>
    </React.Fragment>
    );
  }
}

export default MetaPanel;
