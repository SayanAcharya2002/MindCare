import React from "react";
import firebase from "../../firebase";
import { connect } from "react-redux";
import { setCurrentChannel, setPrivateChannel } from "../../actions";
import { Menu, Icon,Button } from "semantic-ui-react";

class DirectMessages extends React.Component {
  state = {
    activeChannel: "",
    user: this.props.currentUser,
    users: [],
    usersRef: firebase.database().ref("users"),
    connectedRef: firebase.database().ref(".info/connected"),
    presenceRef: firebase.database().ref("presence")
  };

  componentDidMount() {
    if (this.state.user) {
      this.addListeners(this.state.user.uid);
    }
  }

  componentWillUnmount() {
    this.removeListeners();
  }

  removeListeners = () => {
    this.state.usersRef.off();
    this.state.presenceRef.off();
    this.state.connectedRef.off();
  };

  addListeners = currentUserUid => {
    let loadedUsers = [];
    this.state.usersRef.on("child_added", snap => {
      if (currentUserUid !== snap.key) {
        let user = snap.val();
        user["uid"] = snap.key;
        user["status"] = "offline";
        loadedUsers.push(user);
        this.setState({ users: loadedUsers });
      }
    });

    this.state.connectedRef.on("value", snap => {
      if (snap.val() === true) {
        const ref = this.state.presenceRef.child(currentUserUid);
        ref.set(true);
        ref.onDisconnect().remove(err => {
          if (err !== null) {
            console.error(err);
          }
        });
      }
    });

    this.state.presenceRef.on("child_added", snap => {
      if (currentUserUid !== snap.key) {
        this.addStatusToUser(snap.key);
      }
    });

    this.state.presenceRef.on("child_removed", snap => {
      if (currentUserUid !== snap.key) {
        this.addStatusToUser(snap.key, false);
      }
    });
  };

  addStatusToUser = (userId, connected = true) => {
    const updatedUsers = this.state.users.reduce((acc, user) => {
      if (user.uid === userId) {
        user["status"] = `${connected ? "online" : "offline"}`;
      }
      return acc.concat(user);
    }, []);
    this.setState({ users: updatedUsers });
  };

  isUserOnline = user => user.status === "online";

  changeChannel = user => {
    const channelId = this.getChannelId(user.uid);
    const channelData = {
      id: channelId,
      name: user.name
    };
    this.props.setCurrentChannel(channelData);
    this.props.setPrivateChannel(true);
    this.setActiveChannel(user.uid);
  };

  getChannelId = userId => {
    const currentUserId = this.state.user.uid;
    return userId < currentUserId
      ? `${userId}/${currentUserId}`
      : `${currentUserId}/${userId}`;
  };

  setActiveChannel = userId => {
    this.setState({ activeChannel: userId });
  };
  getName=users=>{
    var json=JSON.parse(users);
    return json.name;
  };
  render() {
    const { users, activeChannel } = this.state;
    // console.log("hi")
    // 
    //   console.log(arr.name)
    // console.log(this.getName(users))
    if(!this.props.currentUser.displayName.includes('Dr')){
      
      
      if(true)
      return (
      <Menu.Menu className="menu">
        <Menu.Item>
          <span>
            <Icon name="chevron right" /> DIRECT MESSAGES
          </span>{" "}
          {/* ({users.length}) */}
        </Menu.Item>
        {users.map(user => (
        <Menu.Item
            
            key={user.name.includes('Dr')?user.uid:null}
            active={user.name.includes('Dr')?user.uid === activeChannel:null}
            onClick={user.name.includes('Dr')?() => this.changeChannel(user):null}
            style={user.name.includes('Dr')?{ opacity: 0.7, fontStyle: "italic" }:null}
          >
            {user.name.includes('Dr')?(<Icon
              name="circle"
              color={this.isUserOnline(user)? "green" : "red"}
            />):null}
            
            {user.name.includes('Dr')?user.name:null}
          </Menu.Item>
        ))}
        <a href="https://productathon.000webhostapp.com/appointment.php">
        <Button
        onClick={this.sendMessage}
        // disabled={loading}
        color="red"
        content="Book Appointment"
        labelPosition="right"
        icon="hand pointer outline"
        style={{marginTop:"2em"}}
      />
      </a>
      </Menu.Menu>
     );
     else return(
       <Menu.Menu>
         
       </Menu.Menu>
     );
    
    }else return(
      <Menu.Menu className="menu">
        <Menu.Item>
          <span>
            <Icon name="chevron right" /> DIRECT MESSAGES
          </span>{" "}
          ({users.length})
        </Menu.Item>
       
        {users.map(user => (
          <Menu.Item
            key={user.uid}
            active={user.uid === activeChannel}
            onClick={() => this.changeChannel(user)}
            style={{ opacity: 0.7, fontStyle: "italic" }}
          >
            <Icon
              name="circle"
              color={this.isUserOnline(user) ? "green" : "red"}
            />
            {user.name}
          </Menu.Item>
        ))}
        <a href="https://productathon.000webhostapp.com/appointment.php">
        <Button
        onClick={this.sendMessage}
        // disabled={loading}
        color="red"
        content="Book Appointment"
        labelPosition="right"
        icon="hand pointer outline"
        style={{marginTop:"2em"}}
      />
      </a>
      </Menu.Menu>
    )
  }
}

export default connect(
  null,
  { setCurrentChannel, setPrivateChannel }
)(DirectMessages);
