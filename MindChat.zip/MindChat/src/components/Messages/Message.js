import React from "react";
import moment from "moment";
import { Comment, Image } from "semantic-ui-react";

const isOwnMessage = (message, user) => {
  return message.user.id === user.uid ? "message__self" : "";
};

const isImage = message => {
  return message.hasOwnProperty("image") && !message.hasOwnProperty("content");
};
var a = ["Small", "Blue", "Large","Brave","Cunning","Intelligent","Cute","Friendly","Stabbing","Bad","Naughty"];
var b = ["Bear", "Dog", "Tom","Cat","Mouse","Lion","Tiger","Gorilla","Panda","Leopard","Buffalo","Rhino","Elephant","Bull","Badger"];

function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min) + min); 
}
const isGenerate=()=>{
  
  return a[Math.floor(Math.random()*a.length)] + b[Math.floor(Math.random()*b.length)]+getRandomInt(0,1000000);
}

const timeFromNow = timestamp => moment(timestamp).fromNow();


const Message = ({ message, user }) => (
  <Comment>
    <Comment.Avatar src={message.user.avatar} />
    <Comment.Content className={isOwnMessage(message, user)}>
      
      <Comment.Author as="a">{((message.user.name).toLocaleLowerCase()).includes('dr')?(message.user.name):('Anonymous'+isGenerate(user))}</Comment.Author>
      <Comment.Metadata>{timeFromNow(message.timestamp)}</Comment.Metadata>
      {isImage(message) ? (
        <Image src={message.image} className="message__image" />
      ) : (
        <Comment.Text>{message.content}</Comment.Text>
      )}
    </Comment.Content>
  </Comment>
);

export default Message;
