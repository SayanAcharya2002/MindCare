<?php
//get data from form  
$name = $_POST['name'];
$email= $_POST['email'];
$mobile= $_POST['mobile'];
$subject= $_POST['subject'];
$message= $_POST['message'];
$to = "intelligent.mentalhealth@gmail.com";
$mailsubject = "Mail From MindCare";
$txt ="Name = ". $name . "\r\n  Email = " . $email . "\r\n Mobile = " . $mobile . "\r\n Subject = " . $subject . "\r\n Message =" . $message;
$headers = "From: noreply@MindCare.netlify.app" . "\r\n" .
"CC: somebodyelse@example.com";
if($email!=NULL){
    mail($to,$mailsubject,$txt,$headers);
}
//redirect
header("Location:https://mind-care.netlify.app/");
?>
